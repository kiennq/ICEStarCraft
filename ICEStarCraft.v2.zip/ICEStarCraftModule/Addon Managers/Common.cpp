#include "Common.h"

InformationManager* informationManager;
WorkerManager* workerManager;
ProductionManager* productionManager;
BaseManager* baseManager;
SupplyManager* supplyManager;
UnitGroupManager * unitGroupManager;