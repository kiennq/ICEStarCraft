#pragma once
#include <BWAPI.h>
#include <BWTA.h>
#include "Common.h"

class BaseClass
{

	
	 
};

//public:
//
//	BWAPI::Unit* CreateBase(BWTA::BaseLocation* b,bool haveGas);
//	BWTA::BaseLocation* getBaseLocation() const;
//	bool isMinedOut(){return MinedOut;}
//	const std::set<BWAPI::Unit*>& getMinerals() const;
//	const std::set<BWAPI::Unit*>& getGeysers() const;
//	UnitSet mbase;
//	UnitSet mMinerals;
//
//private:
//
//	BWTA::BaseLocation* baseLocation;
//	bool MinedOut;