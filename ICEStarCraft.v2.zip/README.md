ICEStarCraft project.
Second edition.
